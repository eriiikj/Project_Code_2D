#!/bin/bash
echo "rm -rf build/; mkdir build"
rm -rf build/; mkdir build
