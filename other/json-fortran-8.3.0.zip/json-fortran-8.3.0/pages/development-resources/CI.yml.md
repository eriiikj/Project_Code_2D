title: CI.yml

This is the
[GitHub Actions](https://github.com/jacobwilliams/json-fortran/actions) script
used to perform continuous integration testing for JSON-Fortran, and
trigger automatic documentation deployment.

```yml
{!.github/workflows/CI.yml!}
```
