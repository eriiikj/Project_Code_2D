title: gccr.pl

Below is the source code for `gccr.pl`, which was downloaded from
<https://github.com/eel3/gccr> on July 23, 2015. This script is used
by the [`build.sh`](build.sh.html) script to merge the code coverage
information for the [coverage report](json_module.F90.gcov.html).

```perl
{!pages/development-resources/gccr.pl!}
```
